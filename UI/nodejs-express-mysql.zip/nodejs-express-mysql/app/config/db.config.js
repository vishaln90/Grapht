module.exports = {
  HOST: "localhost",
  USER: "admin",
  PASSWORD: "admin@123",
  DB: "graphologytest"
};